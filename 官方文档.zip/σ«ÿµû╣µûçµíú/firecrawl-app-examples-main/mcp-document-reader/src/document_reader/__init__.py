# src/document_reader/__init__.py
from .server import read_pdf, read_docx, mcp
