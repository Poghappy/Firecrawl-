def main():
    print("Hello from db-pipeline!")


if __name__ == "__main__":
    main()
