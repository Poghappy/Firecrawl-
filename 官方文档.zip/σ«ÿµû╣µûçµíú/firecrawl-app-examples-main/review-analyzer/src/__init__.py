"""
Review Analyzer package.
Contains modules for scraping and analyzing product reviews.
""" 